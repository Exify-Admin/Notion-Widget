import { useEffect, useState } from 'react';

interface LocationData {
  city: string;
  country: string;
  ip: string;
}

export function TimeWidget() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [locationData, setLocationData] = useState<LocationData | null>(null);

  useEffect(() => {
    // Mock IP geolocation data (in a real app, this would come from an API like ipapi.co)
    const mockLocationData: LocationData = {
      city: 'Los Angeles',
      country: 'USA',
      ip: '203.0.113.10'
    };
    setLocationData(mockLocationData);

    // Update time every second
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatLocalTime = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    };
    return date.toLocaleString('en-US', options);
  };

  const formatKoreaTime = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
      timeZone: 'Asia/Seoul'
    };
    return date.toLocaleString('en-US', options);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 p-6">
      <div className="w-[420px] bg-white rounded-[14px] shadow-[0_2px_12px_rgba(0,0,0,0.08)] border border-gray-100 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-[15px] font-semibold text-gray-900">Time</h1>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 rounded-full">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-[13px] font-medium text-green-700">Live</span>
          </div>
        </div>

        {/* Panel 1: Local Time */}
        <div className="bg-white border border-gray-200 rounded-[12px] p-5 mb-3">
          <div className="text-[12px] font-medium text-gray-500 mb-3 uppercase tracking-wide">
            Your local time (by IP)
          </div>
          <div className="text-[20px] font-semibold text-gray-900 mb-2 leading-tight">
            {formatLocalTime(currentTime)}
          </div>
          {locationData && (
            <div className="text-[13px] text-gray-500">
              {locationData.city}, {locationData.country} • IP: {locationData.ip}
            </div>
          )}
        </div>

        {/* Panel 2: Korea Time */}
        <div className="bg-blue-50/50 border border-blue-100/50 rounded-[12px] p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="text-[12px] font-medium text-gray-500 uppercase tracking-wide">
              Korea time (Asia/Seoul)
            </div>
            <div className="px-2.5 py-1 bg-blue-100 rounded-full">
              <span className="text-[11px] font-semibold text-blue-700">KST</span>
            </div>
          </div>
          <div className="text-[20px] font-semibold text-gray-900 leading-tight">
            {formatKoreaTime(currentTime)}
          </div>
        </div>
      </div>
    </div>
  );
}
