import { TimeWidget } from './components/TimeWidget';

export default function App() {
  return (
    <div className="size-full" style={{ fontFamily: 'Inter, sans-serif' }}>
      <TimeWidget />
    </div>
  );
}
